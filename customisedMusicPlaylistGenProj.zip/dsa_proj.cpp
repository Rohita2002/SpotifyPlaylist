#include <iostream>
#include <string>
#include "TextTable.h"

using namespace std;

class Song
{ // defining the structure of a single song and its functions.
private:
    string songName;
    string artistName;
    string albumName;
    string description;
    Song *nextSong;

public:
    string getSongName();
    void setSongName(string sn);
    string getArtistName();
    void setArtistName(string arn);
    string getAlbumName();
    void setAlbumName(string aln);
    string getDesc();
    void setDesc(string d);
    Song *getNextSong();
    void setNextSong(Song *n);
};

class PlayList
{
    // defining the structure of palylist and its functions.
public:
    Song *newSong;
    Song *listSongs;
    Song *tempSong;
    Song *prevSong;
    Song *userPlaylist;

    void createSong(string songName, string artistName, string albumName, string description, Song **currentWorkingPlaylist);
    void displayingAsPerPref(Song **currentWorkingPlaylist);
    void displaySong(Song **currentWorkingPlaylist);
    void findSong(int key, Song **currentWorkingPlaylist);
    void deleteSong(string key, Song **currentWorkingPlaylist);
    void mergeSorting(Song **currentWorkingPlaylist);
    void FindMiddle(Song *cur, Song **first, Song **second);
    Song *MergeBoth(Song *first, Song *second);
};

void User(); // declaring the function calls
void Admin();

string Song::getSongName()
{
    return songName; // returning the songname through the function call since it is declared private in the Song class
}

void Song::setSongName(string sn)
{
    songName = sn; // setting the songname through the function call since it is declared private in the Song class
}

string Song::getArtistName()
{
    return artistName; // returning the artistname through the function call since it is declared private in the Song class
}

void Song::setArtistName(string arn)
{
    artistName = arn; // setting the artistname through the function call since it is declared private in the Song class
}

string Song::getAlbumName()
{
    return albumName; // returning the albumname through the function call since it is declared private in the Song class
}

void Song::setAlbumName(string aln)
{
    albumName = aln; // setting the albumname through the function call since it is declared private in the Song class
}

string Song::getDesc()
{
    return description; // returning the description through the function call since it is declared private in the Song class
}

void Song::setDesc(string d)
{
    description = d; // setting the description through the function call since it is declared private in the Song class
}

Song *Song::getNextSong()
{
    return nextSong; // returning the pointer to the next song through the function call since it is declared private in the Song class
}

void Song::setNextSong(Song *n)
{
    nextSong = n; // setting the pointer to the next song through the function call since it is declared private in the Song class
}

void PlayList::createSong(string songName, string artistName, string albumName, string description, Song **currentWorkingPlaylist)
{
    newSong = new Song;

    newSong->setSongName(songName);
    newSong->setArtistName(artistName); // loading the data into the newly created song node.

    newSong->setAlbumName(albumName);
    newSong->setDesc(description);

    newSong->setNextSong(NULL);

    if (*currentWorkingPlaylist == NULL)
    {
        *currentWorkingPlaylist = newSong; // checking if the current working playlist is empty and inserting the song node as the head.
    }

    else
    {
        tempSong = *currentWorkingPlaylist;
        while (tempSong != NULL)
        {
            prevSong = tempSong; // if the current working playlist is not null, the playlist is traversed to the end and the song node is inserted at the end.
            tempSong = tempSong->getNextSong();
        }
        prevSong->setNextSong(newSong);
    }
}

void PlayList::displaySong(Song **currentWorkingPlaylist)
{
    tempSong = *currentWorkingPlaylist;

    if (tempSong == NULL)
    {
        cout << "PlayList is empty" << endl; // checking if the current working playlist is empty
    }

    else
    {
        TextTable t('-', '|', '+');
        t.add("SongName");
        t.add("ArtistName");
        t.add("AlbumName");
        t.add("Genre");
        t.endOfRow();

        while (tempSong != NULL)
        { // if the current working playlist is not empty, the playlist is displayed by traversing through each song node and loading it into the table.
            t.add(tempSong->getSongName());
            t.add(tempSong->getArtistName());
            t.add(tempSong->getAlbumName());
            t.add(tempSong->getDesc());
            t.endOfRow();

            tempSong = tempSong->getNextSong();
        }

        t.setAlignment(2, TextTable::Alignment::RIGHT);
        cout << t;
    }
}

void PlayList::findSong(int key, Song **currentWorkingPlaylist)
{
    tempSong = *currentWorkingPlaylist;
    int i = 1;
    int found = 0;
    TextTable t('-', '|', '+');

    if (key == 0)
    { // condition to check for the song using songname is satisfied!!
        string x;
        cout << "Enter the Song Name:" << endl;
        cin >> x;
        string temp;

        getline(cin, temp, '\n');

        while (tempSong != NULL)
        {
            if ((x + temp) == tempSong->getSongName())
            { // checking if the song with the given song name is existing in the playlist and console outing all the found songs.
                found++;

                if (found == 1)
                {
                    t.add("SongName");
                    t.add("ArtistName");
                    t.add("AlbumName");
                    t.add("Genre");
                    t.endOfRow();
                }

                t.add(tempSong->getSongName());
                t.add(tempSong->getArtistName());
                t.add(tempSong->getAlbumName());
                t.add(tempSong->getDesc());
                t.endOfRow();
            }

            tempSong = tempSong->getNextSong();
        }

        t.setAlignment(2, TextTable::Alignment::RIGHT);
        std::cout << t;

        found == 0 ? cout << "Song(s) not found!" << endl : cout << "" << endl; // if song(s) is/are not found
    }

    else if (key == 1)
    {
        // condition to check for the song using artistname is satisfied!!
        string x;
        cout << "Enter the Artist Name:" << endl;
        cin >> x;
        string temp;

        getline(cin, temp, '\n');

        while (tempSong != NULL)
        {
            if ((x + temp) == tempSong->getArtistName())
            { // checking if the song with the given artist name is existing in the playlist and console outing all the found songs.
                found++;

                if (found == 1)
                {
                    t.add("SongName");
                    t.add("ArtistName");
                    t.add("AlbumName");
                    t.add("Genre");
                    t.endOfRow();
                }

                t.add(tempSong->getSongName());
                t.add(tempSong->getArtistName());
                t.add(tempSong->getAlbumName());
                t.add(tempSong->getDesc());
                t.endOfRow();
            }
            tempSong = tempSong->getNextSong();
        }

        t.setAlignment(2, TextTable::Alignment::RIGHT);
        std::cout << t;

        found == 0 ? cout << "Song(s) not found!" << endl : cout << "" << endl; // if song(s) is/are not found
    }

    else if (key == 2)
    {
        // condition to check for the song using albumname is satisfied!!
        string x;
        cout << "Enter the Album Name:" << endl;
        cin >> x;
        string temp;

        getline(cin, temp, '\n');

        while (tempSong != NULL)
        {
            if ((x + temp) == tempSong->getAlbumName())
            { // checking if the song with the given album name is existing in the playlist and console outing all the found songs.
                found++;

                if (found == 1)
                {
                    t.add("SongName");
                    t.add("ArtistName");
                    t.add("AlbumName");
                    t.add("Genre");
                    t.endOfRow();
                }

                t.add(tempSong->getSongName());
                t.add(tempSong->getArtistName());
                t.add(tempSong->getAlbumName());
                t.add(tempSong->getDesc());
                t.endOfRow();
            }
            tempSong = tempSong->getNextSong();
        }

        t.setAlignment(2, TextTable::Alignment::RIGHT);
        std::cout << t;

        found == 0 ? cout << "Song(s) not found!" << endl : cout << "" << endl; // if song(s) is/are not found
    }

    else if (key == 3)
    {
        // condition to check for the song using description is satisfied!!
        string x;
        cout << "Enter the genre:" << endl;
        cin >> x;
        string temp;

        getline(cin, temp, '\n');

        while (tempSong != NULL)
        {
            if ((x + temp) == tempSong->getDesc())
            { // checking if the song with the given description is existing in the playlist and console outing all the found songs.
                found++;

                if (found == 1)
                {
                    t.add("SongName");
                    t.add("ArtistName");
                    t.add("AlbumName");
                    t.add("Genre");
                    t.endOfRow();
                }

                t.add(tempSong->getSongName());
                t.add(tempSong->getArtistName());
                t.add(tempSong->getAlbumName());
                t.add(tempSong->getDesc());
                t.endOfRow();
            }
            tempSong = tempSong->getNextSong();
        }

        t.setAlignment(2, TextTable::Alignment::RIGHT);
        std::cout << t;

        found == 0 ? cout << "Song(s) not found!" << endl : cout << "" << endl; // if song(s) is/are not found
    }
}

void PlayList::deleteSong(string key, Song **currentWorkingPlaylist)
{
    tempSong = *currentWorkingPlaylist;
    prevSong = NULL;
    int deleted = 0;

    if (tempSong == NULL)
    {
        cout << "No songs in the library to delete" << endl; // checking if the playlist is empty
        deleted = -1;
    }

    else
    {
        while (tempSong != NULL)
        { // traversing through the playlist
            if (key == tempSong->getSongName())
            {
                deleted = 1;

                if (prevSong == NULL && tempSong->getNextSong() == NULL)
                { // case where the song is found in the playlist and there is only one song in the playlist.
                    *currentWorkingPlaylist = NULL;
                    break;
                }

                if (prevSong == NULL && tempSong->getNextSong() != NULL)
                { // case where the song is found and is the very first song in the playlist
                    prevSong = tempSong;
                    cout << tempSong->getSongName() << " from " << tempSong->getAlbumName();
                    *currentWorkingPlaylist = tempSong->getNextSong();
                    prevSong->setNextSong(NULL);
                    tempSong = *currentWorkingPlaylist;
                }

                else
                {
                    cout << tempSong->getSongName() << " from " << tempSong->getAlbumName(); // case where the key song is non-first node and deleteting it.
                    prevSong->setNextSong(tempSong->getNextSong());
                }
                cout << " Deleted!! " << endl;
            }

            else
            {
                prevSong = tempSong;
            }

            tempSong = tempSong->getNextSong(); // looping through the playlist since there can be multiple songs with the same songname by different artists, or from different albums or in different genres
        }
    }

    deleted == 0 ? cout << "Song(s) not found!" << endl : cout << "" << endl; // if song(s) is/are not found
}

void PlayList::mergeSorting(Song **currentWorkingPlaylist)
{ // MergeSorting technique used for sorting the playlist(LinkedList)
    Song *cur = *currentWorkingPlaylist;

    Song *first;
    Song *second;

    if (!cur || !cur->getNextSong())
        return; // checking if the playlist is empty or exactly having a one song and returning (since the playlist is already sorted in this case)

    // else
    FindMiddle(cur, &first, &second); // function to find the middle element and slice it into different playlists.

    mergeSorting(&first);  // recursively sorting the first half of the playlist
    mergeSorting(&second); // recursively sorting the second half of the playlist

    *currentWorkingPlaylist = MergeBoth(first, second);
}

void PlayList ::FindMiddle(Song *cur, Song **first, Song **second)
{
    Song *fast;
    Song *slow;

    slow = cur;                // pointing to the head of the playlist
    fast = cur->getNextSong(); // pointing to the second node of the playlist

    while (fast != NULL)
    {
        fast = fast->getNextSong();

        if (fast != NULL)
        { // fast pointer moves at 2x speed compared to the slow pointer
            slow = slow->getNextSong();
            fast = fast->getNextSong();
        }
    }

    *first = cur;
    *second = slow->getNextSong(); // the middle node is the node pointed by the slow pointer.
    slow->setNextSong(NULL);
}

Song *PlayList ::MergeBoth(Song *first, Song *second)
{
    Song *sorted = NULL; // loading the sorted playlist into the 'sorted' playlist

    if (!first)
        return second; // case where only 1 or 2 songs are available in the playlist

    else if (!second)
        return first;

    if (first->getSongName() <= second->getSongName())
    { // if the first songname is less than the second songname alphabetically, the first songname gets inserted before the second songname
        sorted = first;
        sorted->setNextSong(MergeBoth(first->getNextSong(), second));
    }

    else
    {
        sorted = second; // if the first songname is greater than the second songname alphabetically, the first songname gets inserted after the second songname
        sorted->setNextSong(MergeBoth(first, second->getNextSong()));
    }

    return sorted;
}

PlayList p;

void initailizeSongs()
{ // initializing the playlist with some songs(songname, artistname, albumname, genre) into the default playlist
    p.createSong("STAY", "Justin Beiber", "Over You", "EPOP", &(p.listSongs));
    p.createSong("Infinity", "Jaymes Young", "Feel Something", "Melancholy", &(p.listSongs));
    p.createSong("Style", "Taylor Swift", "Red", "Country", &(p.listSongs));
    p.createSong("Chaka chak", "Shreya Ghosal", "Atrangi Re", "Bollywood", &(p.listSongs));
    p.createSong("No Lie", "Dua Lipa", "Mad Love", "EPOP", &(p.listSongs));
    p.createSong("The Story", "Conan Gray", "Kid Krow", "Country", &(p.listSongs));
    p.createSong("Crush Culture", "Conan Gray", "Kid Krow", "Country", &(p.listSongs));
    p.createSong("Generation Why", "Conan Gray", "Kid Krow", "Country", &(p.listSongs));
    p.createSong("Moh Moh ke daage", "Shreya Ghosal", "Jhor laga ke", "Bollywood", &(p.listSongs));
    p.createSong("Param Sundari", "Shreya Ghosal", "MiMi", "Bollywood", &(p.listSongs));
    p.createSong("Best Days", "Alessia Clara", "In the Meantime", "EPOP", &(p.listSongs));
    p.createSong("Box In the Ocean", "Alessia Clara", "In the Meantime", "EPOP", &(p.listSongs));
    p.createSong("Lie to Me", "Alessia Clara", "In the Meantime", "EPOP", &(p.listSongs));
    p.createSong("Hututu", "Sashaa Tirupati", "MiMi", "Bollywood", &(p.listSongs));
    p.createSong("Better", "ATEEZ", "Zero:Fever", "KPOP", &(p.listSongs));
    p.createSong("Waves", "ATEEZ", "Zero:Fever", "KPOP", &(p.listSongs));
    p.createSong("Still Here", "ATEEZ", "Zero:Fever", "KPOP", &(p.listSongs));
    p.createSong("Letter", "ATEEZ", "Zero:Fever", "KPOP", &(p.listSongs));
    p.createSong("High School Me", "Sasha Alex Sloan", "Only Child", "Melancholy", &(p.listSongs));
    p.createSong("People Watching", "Conan Gray", "People", "EPOP", &(p.listSongs));
    p.createSong("April in Paris", "Billie Holiday", "All or Nothing", "Jazz", &(p.listSongs));
    p.createSong("Speak Low", "Billie Holiday", "All or Nothing", "Jazz", &(p.listSongs));
    p.createSong("Blue Moon", "Billie Holiday", "Solitude", "Jazz", &(p.listSongs));
    p.createSong("This is Always", "Betty Carter", "Inside Betty", "Jazz", &(p.listSongs));
    p.createSong("Kasoor", "Prateek Kuhad", "Kasoor", "Indie", &(p.listSongs));
    p.createSong("Sheher ki baatein", "Prateek Kuhad", "Kasoor", "Indie", &(p.listSongs));
    p.createSong("Koh gaye hum", "Prateek Kuhad", "Baar Baar dekho", "Melancholy", &(p.listSongs));
    p.createSong("Unholy", "Miley Cyrus", "SHE IS COMING", "Melancholy", &(p.listSongs));
    p.createSong("Let's Fall in love", "Finneas", "blood harmony", "Melancholy", &(p.listSongs));
    p.createSong("Kill This Love", "BlackPink", "Kill this Love", "KPOP", &(p.listSongs));
    p.createSong("Maria", "Hwasa", "Maria", "KPOP", &(p.listSongs));
    p.createSong("I'm bad too", "Hwasa", "Maria", "KPOP", &(p.listSongs));
    p.createSong("What type of b", "Jessi", "type", "KPOP", &(p.listSongs));
    p.createSong("Nunu nana", "Jessi", "type", "KPOP", &(p.listSongs));
    p.createSong("Euphoria", "Chymes", "Euphoria", "KPOP", &(p.listSongs));
    p.createSong("Euphoria", "JIN", "Blood and Sweat", "KPOP", &(p.listSongs));
}

void Admin()
{
    int i = 0;
    // displaying all the functionalities that an admin is able to do.
    cout << "___________________________________________________________________________________________________________" << endl;
    cout << "___________________________________________________________________________________________________________" << endl;
    cout << "Choose your action :" << endl;
    cout << "1.Initialize the default playlist: (Note: You can initialize the default playlist only once)" << endl;
    cout << "2.Add new song to the library" << endl;
    cout << "3.Display your music library :" << endl;
    cout << "4.Find a song from the library:" << endl;
    cout << "5. Delete a song from the library:" << endl;
    cout << "6.Exit" << endl;
    cout << "7.Switch to User" << endl;
    cout << "                                              " << endl;
    cout << "                                              " << endl;

    cin >> i;

    if (i == 1)
    { // initializing the playlist with some hard coded songs and again calling the admin for his next action until he exit.
        initailizeSongs();
        cout << "Default playlist is created!" << endl;
        Admin();
    }

    else if (i == 2)
    { // adding a new song to the existing playlist and again calling the admin for his next action until he exit.
        string songname;
        string artist;
        string album;
        string desc;
        string w;

        cout << "Please Enter the song name:" << endl;
        cin >> w;
        getline(cin, songname, '\n');

        cout << "Enter Artist name:" << endl;
        getline(cin, artist, '\n');

        cout << "Enter album name:" << endl;
        getline(cin, album, '\n');

        cout << "Enter the desc:" << endl;
        getline(cin, desc, '\n');

        p.createSong(w + songname, artist, album, desc, &(p.listSongs));

        cout << "                  " << endl;
        cout << "Song added!" << endl;

        Admin();
    }

    else if (i == 3)
    { // displaying the playlist and again calling the admin for his next action until he exit.

        p.displayingAsPerPref(&(p.listSongs));
        Admin();
    }

    else if (i == 4)
    { // finding and displaying the required song by songname/artistname/albumname/genre and again calling the admin for his next action until he exit.
        int choice;

        cout << "___________________________________________________________________________________________________________" << endl;
        cout << "___________________________________________________________________________________________________________" << endl;

        cout << "1.Find a song by it's name?" << endl;
        cout << "2.Find a song by it's artist?" << endl;
        cout << "3.Find a song by it's album?" << endl;
        cout << "4.Find a song by it's genre?" << endl;

        cout << "                                              " << endl;
        cout << "                                              " << endl;

        cin >> choice;

        if (choice == 1)
        {
            p.findSong(0, &(p.listSongs)); // Finding a song by it's name
        }

        else if (choice == 2)
        {
            p.findSong(1, &(p.listSongs)); // Finding a song by it's artist
        }

        else if (choice == 3)
        {
            p.findSong(2, &(p.listSongs)); // Finding a song by it's album
        }

        else if (choice == 4)
        {
            p.findSong(3, &(p.listSongs)); // Finding a song by it's genre
        }

        Admin();
    }

    else if (i == 5)
    { // deleting the song entered and again calling the admin for his next action until he exit.
        string y;
        cout << "Enter the song name you wish to remove " << endl;
        cin >> y;

        string temp;
        getline(cin, temp, '\n');

        p.deleteSong(y + temp, &(p.listSongs));

        Admin();
    }

    else if (i == 6)
    { // exiting the playlist
        exit;
    }

    else if (i == 7)
    { // switching  to the user functionality.

        cout << "Welcome User" << endl;
        cout << "****************************************************" << endl;

        User();
    }
}

void PlayList::displayingAsPerPref(Song **currentWorkingPlaylist)
{

    if (*currentWorkingPlaylist == NULL)
    {
        cout << "Playlist is empty" << endl; // checking if the current working playlist is empty
    }

    else
    {
        // user can choose from the given option to display the playlist
        int choice;

        cout << "___________________________________________________________________________________________________________" << endl;
        cout << "___________________________________________________________________________________________________________" << endl;

        cout << "Choose the display option" << endl;
        cout << "1.Display the music library" << endl;
        cout << "2.Display the music library sorted alphabetically by the songName" << endl;
        cout << "3.Display songs by a particular Artist" << endl;
        cout << "4.Display songs in a particular Album" << endl;

        cout << "                                              " << endl;
        cout << "                                              " << endl;

        cin >> choice;

        if (choice == 1)
        {
            // Display the music library (unsorted)
            cout << "Get a peek at the music library" << endl;
            cout << "                                " << endl;

            displaySong(currentWorkingPlaylist);
        }

        else if (choice == 2)
        {
            // Display the music library(Sorted)
            mergeSorting(currentWorkingPlaylist);
            displaySong(currentWorkingPlaylist);
        }

        else if (choice == 3)
        {
            // Finding and Displaying songs by a particular Artist
            findSong(1, currentWorkingPlaylist);
        }

        else if (choice == 4)
        {
            // Finding and Dislaying songs in a particular Album
            findSong(2, currentWorkingPlaylist);
        }
    }
}

void InnerUser()
{
    int j = 0;
    // displaying all the functionalities that a user can do regarding their own playlist.

    cout << "___________________________________________________________________________________________________________" << endl;
    cout << "___________________________________________________________________________________________________________" << endl;

    cout << "Want to edit your playlist?" << endl;
    cout << "1.Add a song" << endl;
    cout << "2.Add songs by a particular artist into your playlist from the default playlist" << endl;
    cout << "3.Add songs from a particular album into your playlist from the default playlist" << endl;
    cout << "4.Delete a song" << endl;
    cout << "5.Display the playlist" << endl;
    cout << "6.Exit" << endl;

    cout << "                                              " << endl;
    cout << "                                              " << endl;

    cin >> j;

    if (j == 1)
    { // adding a user preferred song into one's playlist and again calling the user for the next action until exit is chosen.
        string songname;
        string artist;
        string album;
        string desc;
        string w;

        cout << "Please Enter the song name:" << endl;
        cin >> w;
        getline(cin, songname, '\n');

        cout << "Enter Artist name:" << endl;
        getline(cin, artist, '\n');

        cout << "Enter album name:" << endl;
        getline(cin, album, '\n');

        cout << "Enter the desc:" << endl;
        getline(cin, desc, '\n');

        p.createSong(w + songname, artist, album, desc, &(p.userPlaylist));

        cout << "                                " << endl;
        cout << "Song added!" << endl;

        InnerUser();
    }

    else if (j == 2)
    {
        // user can add preferred songs by some particular artist from the existing playlist created by the admin
        string y;

        cout << "Enter the name of the artist you wish to add " << endl;
        cin >> y;

        string temp;

        getline(cin, temp, '\n');

        p.tempSong = p.listSongs;
        int added = 0;
        Song *temporary = NULL;

        while (p.tempSong != NULL)
        {
            if ((y + temp) == p.tempSong->getArtistName())
            {
                // checking if the artistname entered by the user exists in the default playlist created by the admin
                added = 1;
                temporary = p.tempSong;
                p.createSong(p.tempSong->getSongName(), p.tempSong->getArtistName(), p.tempSong->getAlbumName(), p.tempSong->getDesc(), &(p.userPlaylist));
                p.tempSong = temporary;

                cout << p.tempSong->getSongName() << " by " << p.tempSong->getArtistName() << " is added to your playlist" << endl;
            }

            p.tempSong = p.tempSong->getNextSong();
        }

        added == 0 ? cout << "Song(s) not found!" << endl : cout << " " << endl; // if song(s) is/are not found

        InnerUser();
    }

    else if (j == 3)
    {
        // user can add preferred songs from some particluar album from the existing playlist created by the admin
        string y;

        cout << "Enter the name of the album you wish to add " << endl;
        cin >> y;

        string temp;

        getline(cin, temp, '\n');

        p.tempSong = p.listSongs;
        int added = 0;
        Song *temporary = NULL;

        while (p.tempSong != NULL)
        {
            // checking if the albumname entered by the user exists in the default playlist created by the admin
            if ((y + temp) == p.tempSong->getAlbumName())
            {
                added = 1;
                temporary = p.tempSong;
                p.createSong(p.tempSong->getSongName(), p.tempSong->getArtistName(), p.tempSong->getAlbumName(), p.tempSong->getDesc(), &(p.userPlaylist));
                p.tempSong = temporary;

                cout << p.tempSong->getSongName() << " from " << p.tempSong->getAlbumName() << " is added to your playlist" << endl;
            }

            p.tempSong = p.tempSong->getNextSong();
        }

        added == 0 ? cout << "Song(s) not found!" << endl : cout << " " << endl; // if song(s) is/are not found

        InnerUser();
    }

    else if (j == 4)
    { // deleting the unwanted song from the user playlist and again calling the user for the next action until exit is chosen.
        string y;

        cout << "Enter the song name you wish to remove " << endl;
        cin >> y;

        string temp;
        getline(cin, temp, '\n');

        p.deleteSong(y + temp, &(p.userPlaylist));

        InnerUser();
    }

    else if (j == 5)
    { // displaying the user playlist and again calling the user for the next action until exit is chosen.
        p.displayingAsPerPref(&(p.userPlaylist));

        InnerUser();
    }

    else if (j == 6)
    { // user is exited from editing his playlist but not from his profile.
        exit;
    }
}

void User()
{
    int i = 0;

    // displaying all the functionalities that a user can do.
    cout << "___________________________________________________________________________________________________________" << endl;
    cout << "___________________________________________________________________________________________________________" << endl;

    cout << "Choose what you want to do :" << endl;

    cout << "1.View the muscic library" << endl;
    cout << "2.Create your own playlist" << endl;
    cout << "3.Exit" << endl;

    cout << "                                              " << endl;
    cout << "                                              " << endl;

    cin >> i;

    if (i == 1)
    { // displaying the playlist that is already created by the admin which is considered as the default playlist for the user and again calling the user for the next action until the exit is chosen.
        cout << "                                             " << endl;

        cout << "Default PlayList" << endl;
        p.displayingAsPerPref(&(p.listSongs));

        cout << "                                             " << endl;

        cout << "User PlayList" << endl;
        p.displayingAsPerPref(&(p.userPlaylist));

        User();
    }

    else if (i == 2)
    { // jump to the functionalities to create the user's playlist and again calling the user for the next action until the exit is chosen.
        InnerUser();

        User();
    }

    else if (i == 3)
    { // user is exited from one's profile.
        exit;
    }
}

int main()
{

    cout << "***********************************************" << endl;
    cout << "Welcome to BITS Playlist Generator" << endl;

    cout << "***********************************************" << endl;

    cout << "Give Login Credentials" << endl;

    cout << "Enter the username: " << endl;
    string profile;
    getline(cin, profile, '\n');

    cout << "Enter the password: " << endl;
    string password;
    getline(cin, password, '\n');

    if (profile == "Admin" && password == "Admin@123")
    { // jump to admin functionality if 'admin' is chosen.
        cout << "Welcome Admin" << endl;
        cout << "****************************************************" << endl;

        Admin();
    }

    else if (profile == "User" && password == "User@123")
    { // jump to user functionality if 'user' is chosen.
        cout << "Welcome User" << endl;
        cout << "****************************************************" << endl;

        User();
    }

    return 0;
}
